import menu from './funciones.js';
menu();